#include <iostream>

using namespace std;

class NODD {
public:
    NODD* lchild;
    int data;
    string word;
    NODD* rchild;
    int height;
};

class AVL{
public:
    NODD* root;

    AVL(){ root = nullptr; }

    // Helper methods for inserting
    int NODDHeight(NODD* p);
    int BalanceFactor(NODD* p);
    NODD* LLRotation(NODD* p);
    NODD* RRRotation(NODD* p);
    NODD* LRRotation(NODD* p);
    NODD* RLRotation(NODD* p);

    // Insert
    NODD* rInsert(NODD* p, int key, string word);

    // Traversal
    void Inorder(NODD* p);
    void Inorder(){ Inorder(root); }
    NODD* getRoot(){ return root; }
};

int AVL::NODDHeight(NODD *p) {
    int hl;
    int hr;

    hl = (p && p->lchild) ? p->lchild->height : 0;
    hr = (p && p->rchild) ? p->rchild->height : 0;

    return hl > hr ? hl + 1 : hr + 1;
}

int AVL::BalanceFactor(NODD *p) {
    int hl;
    int hr;

    hl = (p && p->lchild) ? p->lchild->height : 0;
    hr = (p && p->rchild) ? p->rchild->height : 0;

    return hl - hr;
}

NODD* AVL::LLRotation(NODD *p) {
    NODD* pl = p->lchild;
    NODD* plr = pl->rchild;

    pl->rchild = p;
    p->lchild = plr;

    // Update height
    p->height = NODDHeight(p);
    pl->height = NODDHeight(pl);

    // Update root
    if (root == p){
        root = pl;
    }
    return pl;
}

NODD* AVL::RRRotation(NODD *p) {
    NODD* pr = p->rchild;
    NODD* prl = pr->lchild;

    pr->lchild = p;
    p->rchild = prl;

    // Update height
    p->height = NODDHeight(p);
    pr->height = NODDHeight(pr);

    // Update root
    if (root == p){
        root = pr;
    }
    return pr;
}

NODD* AVL::LRRotation(NODD *p) {
    return nullptr;
}

NODD* AVL::RLRotation(NODD *p) {
    return nullptr;
}

NODD* AVL::rInsert(NODD *p, int key, string value) {
    NODD* t;
    if (p == nullptr){
        t = new NODD;
        t->data = key;
        t->word = value;
        t->lchild = nullptr;
        t->rchild = nullptr;
        t->height = 1;  // Starting height from 1 onwards instead of 0
        return t;
    }

    if (key < p->data){
        p->lchild = rInsert(p->lchild, key,value);
    } else if (key > p->data){
        p->rchild = rInsert(p->rchild, key,value);
    }

    // Update height
    p->height = NODDHeight(p);

    // Balance Factor and Rotation
    if (BalanceFactor(p) == 2 && BalanceFactor(p->lchild) == 1) {
        return LLRotation(p);
    } else if (BalanceFactor(p) == 2 && BalanceFactor(p->lchild) == -1){
        return LRRotation(p);
    } else if (BalanceFactor(p) == -2 && BalanceFactor(p->rchild) == -1){
        return RRRotation(p);
    } else if (BalanceFactor(p) == -2 && BalanceFactor(p->rchild) == 1){
        return RLRotation(p);
    }

    return p;
}

void AVL::Inorder(NODD *p) {
    if (p){
        Inorder(p->lchild);
        cout << p->data << ", " << flush;
        Inorder(p->rchild);
    }
}
