
#include <iostream>

#include <string>






using namespace std;

// Linked List node

// Linked List node

class Node{

public:
    int data;
    string wordd;
    Node* next;
};
// Hash Table
class HashTable{

public:
    Node** HT;
    HashTable();
    int hash(int key);
    void Insert(string key);
    string Search(int key);
    ~HashTable();
};

HashTable::HashTable() {
    HT = new Node* [10];
    for (int i=0; i<10; i++){
        HT[i] = nullptr;
    }
}

int HashTable::hash(int key) {
    return key % 10;
}

void HashTable::Insert(string wrdds) {
    int key=wrdds.size();
    int hIdx = hash(key);
    Node* t = new Node;
    t->data = key;
    t->wordd=wrdds;
    t->next = nullptr;
    // Case: No nodes in the linked list
    if (HT[hIdx] == nullptr){
        HT[hIdx] = t;
    } else {
        Node* p = HT[hIdx];
        Node *q=HT[hIdx];
        // Traverse to find insert position
        while (p && p->data < key){
            q=p;
            p = p->next;
        }
        // Case: insert position is first
        if (q == HT[hIdx]){
            t->next = HT[hIdx];
            HT[hIdx] = t;
        } else {
            t->next = q->next;
            q->next = t;
        }
    }
}

string HashTable::Search(int key) {
    int hIdx = hash(key);
    Node* p = HT[hIdx];

    srand(time(NULL));

    int random = rand() % 15;

    for(int m=0; m<random; m++)
        p = p->next;
    if(p==nullptr)
        Search(key);
    return p->wordd;
}


HashTable::~HashTable() {
    for (int i=0; i<10; i++){
        Node* p = HT[i];
        while (HT[i]){
            HT[i] = HT[i]->next;
            delete p;
            p = HT[i];
        }
    }
    delete [] HT;
}